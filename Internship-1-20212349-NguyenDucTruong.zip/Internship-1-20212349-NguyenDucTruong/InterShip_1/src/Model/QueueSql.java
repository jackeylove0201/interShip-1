package Model;

public interface QueueSql {
	public void Add(String url);
					
	public void Update (String url);
		
	public void Remove(String url);
	
		
	

}
